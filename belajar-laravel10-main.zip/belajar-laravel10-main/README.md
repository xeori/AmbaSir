## Repository khusus belajar laravel dari Blues Tutorial

Tonton playlist belajarnya disini : https://www.youtube.com/playlist?list=PLRx0OlyTshRaeJxdgrbHDxQOe8z_Sixhd

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
